package com.kotlin.mvvm.di.base

/**
 * Created by Waheed on 04,November,2019
 */

/**
 * Marks an activity / fragment injectable.
 */
interface Injectable
